package com.example.sanskriti.fitnesslove;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

public class SignUp extends AppCompatActivity {

    private EditText usn, pwd, rpwd, name, eid;
    private Button reg;
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        setupUIViews();

        firebaseAuth= FirebaseAuth.getInstance();
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if( validate())
               {
                   //Upload data
                   String user_mail = eid.getText().toString().trim();
                   String user_Password = pwd.getText().toString();

                   firebaseAuth.createUserWithEmailAndPassword( user_mail, user_Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                       @Override
                       public void onComplete(@NonNull Task<AuthResult> task) {
                           if(task.isSuccessful()) {

                               Toast.makeText(SignUp.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                               startActivity(new Intent(SignUp.this,login_page.class));
                           }
                           else
                           {
                               FirebaseAuthException e = (FirebaseAuthException )task.getException();
                               Toast.makeText(SignUp.this, "Registration Failed "+e.getMessage() , Toast.LENGTH_SHORT).show();

                           }

                       }
                   });
               }
            }
        });

        //For redirecting already signed up user back to registration.

    /*    userLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUp.this, login_page.class
                ));
            }
        });*/
    }

    private void setupUIViews()
    {
        usn=(EditText)findViewById(R.id.username);
        pwd=(EditText)findViewById(R.id.password);
        rpwd=(EditText)findViewById(R.id.repass);
        name=(EditText)findViewById(R.id.name);
        eid=(EditText)findViewById(R.id.emailid);
        reg=(Button) findViewById(R.id.reg);
    }

    private Boolean validate()
    {
        Boolean result= false;
        String username=usn.getText().toString();
        String password=pwd.getText().toString();
        String repassword=rpwd.getText().toString();
        String Naam=name.getText().toString();
        String email=eid.getText().toString();
        if(username.isEmpty()||password.isEmpty()||Naam.isEmpty()||email.isEmpty())
            Toast.makeText(this, "Please Enter All Details", Toast.LENGTH_SHORT).show();
        else
            if(!(password.equals(repassword)))
                Toast.makeText(this, "Password Mismatch!!", Toast.LENGTH_SHORT).show();
            else
                result=true;

            return result;


    }
}
